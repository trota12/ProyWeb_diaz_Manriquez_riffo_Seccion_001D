from django.shortcuts import render

# Create your views here.
def index(request):
    return render (request, 'index.html')

def quienes_somos(request):
    return render (request, 'quienes_somos.html')

def catalogo(request):
    return render (request, 'catalogo.html')

def vision(request):
    return render (request, 'vision.html')