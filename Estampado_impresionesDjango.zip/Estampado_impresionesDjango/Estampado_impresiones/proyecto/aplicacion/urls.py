from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('quienes-somos/', views.quienes_somos, name='quienes_somos'),
    path('vision/', views.vision, name='vision'),
    path('catalogo/', views.catalogo, name='catalogo'),
]